// Content script na página do Infinity Group Finder.
// Ponte: página (postMessage, mesma aba) -> service worker (chrome.runtime).
// Nunca envia cookies, tokens ou credenciais para a página.

const CHANNEL = "infinity-convertmais-bridge";

console.log("[INFINITY CONTENT] bridge content script carregado");

function respond(id, ok, data, error) {
  window.postMessage(
    { channel: CHANNEL, direction: "response", id, ok, data, error },
    window.location.origin,
  );
}

function normalizeAction(action) {
  if (action === "getProducts" || action === "GET_PRODUCTS") return "getProducts";
  if (action === "getPlans" || action === "GET_PLANS") return "getPlans";
  if (action === "getGroups" || action === "GET_GROUPS") return "getGroups";
  if (action === "getGroupDetails" || action === "GET_GROUP_DETAILS") return "getGroupDetails";
  return null;
}

window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  const msg = event.data;
  if (!msg || msg.channel !== CHANNEL || msg.direction !== "request") return;

  const { id, payload } = msg;

  if (msg.action === "ping") {
    respond(id, true, { type: "PONG" });
    return;
  }

  if (msg.action === "ancoraApi" || msg.action === "ANCORA_API") {
    console.log("[INFINITY CONTENT] ANCORA_API request", payload?.path);
    let done = false;
    const ancoraTimer = setTimeout(() => {
      if (done) return;
      done = true;
      respond(id, false, undefined, {
        code: "TIMEOUT",
        message: "O service worker da extensão não respondeu (Âncora).",
      });
    }, 35000);
    try {
      chrome.runtime.sendMessage({ bridge: CHANNEL, type: "ANCORA_API", requestId: id, payload }, (res) => {
        if (done) return;
        done = true;
        clearTimeout(ancoraTimer);
        if (chrome.runtime.lastError) {
          respond(id, false, undefined, {
            code: "UPSTREAM_ERROR",
            message: `Extensão indisponível: ${chrome.runtime.lastError.message}`,
          });
          return;
        }
        if (!res || !res.ok) {
          respond(id, false, undefined, res?.error ?? { code: "UPSTREAM_ERROR", message: "Falha ao consultar a Âncora." });
          return;
        }
        respond(id, true, res.data);
      });
    } catch (err) {
      done = true;
      clearTimeout(ancoraTimer);
      respond(id, false, undefined, {
        code: "UPSTREAM_ERROR",
        message: `Não foi possível falar com a extensão: ${String(err?.message ?? err)}`,
      });
    }
    return;
  }

  if (msg.action === "GET_ANCORA_ASSETS") {
    console.log("[ANCORA BRIDGE] assets request received");
    let done = false;
    const assetsTimer = setTimeout(() => {
      if (done) return;
      done = true;
      respond(id, false, undefined, {
        code: "TIMEOUT",
        message: "O service worker não respondeu à consulta de bens da Âncora.",
      });
    }, 35000);
    chrome.runtime.sendMessage(
      { bridge: CHANNEL, type: "GET_ANCORA_ASSETS", requestId: id, payload },
      (res) => {
        if (done) return;
        done = true;
        clearTimeout(assetsTimer);
        if (chrome.runtime.lastError) {
          respond(id, false, undefined, {
            code: "UPSTREAM_ERROR",
            message: `Extensão indisponível: ${chrome.runtime.lastError.message}`,
          });
          return;
        }
        if (!res?.ok) {
          respond(id, false, undefined, res?.error ?? {
            code: "UPSTREAM_ERROR",
            message: "Falha ao consultar os bens da Âncora.",
          });
          return;
        }
        respond(id, true, res.data);
      },
    );
    return;
  }

  if (msg.action === "GET_ANCORA_PRODUCTS") {
    console.log("[ANCORA BRIDGE] products request received");
    let done = false;
    const productsTimer = setTimeout(() => {
      if (done) return;
      done = true;
      respond(id, false, undefined, {
        code: "TIMEOUT",
        message: "O service worker não respondeu ao teste de produtos da Âncora.",
      });
    }, 35000);
    chrome.runtime.sendMessage(
      { bridge: CHANNEL, type: "GET_ANCORA_PRODUCTS", requestId: id },
      (res) => {
        if (done) return;
        done = true;
        clearTimeout(productsTimer);
        if (chrome.runtime.lastError) {
          respond(id, false, undefined, {
            code: "UPSTREAM_ERROR",
            message: `Extensão indisponível: ${chrome.runtime.lastError.message}`,
          });
          return;
        }
        if (!res?.ok) {
          respond(id, false, undefined, res?.error ?? {
            code: "UPSTREAM_ERROR",
            message: "Falha ao consultar os produtos da Âncora.",
          });
          return;
        }
        respond(id, true, res.data);
      },
    );
    return;
  }

  const action = normalizeAction(msg.action);
  if (!action) {
    respond(id, false, undefined, { code: "UPSTREAM_ERROR", message: "Ação não suportada." });
    return;
  }

  const type =
    action === "getPlans"
      ? "GET_PLANS"
      : action === "getGroups"
        ? "GET_GROUPS"
        : action === "getGroupDetails"
          ? "GET_GROUP_DETAILS"
          : "GET_PRODUCTS";
  console.log("[INFINITY CONTENT] request received", type, id);

  let settled = false;
  const timer = setTimeout(() => {
    if (settled) return;
    settled = true;
    console.warn("[INFINITY CONTENT] timeout esperando service worker");
    respond(id, false, undefined, {
      code: "TIMEOUT",
      message: "O service worker da extensão não respondeu.",
    });
  }, 30000);

  try {
    chrome.runtime.sendMessage({ bridge: CHANNEL, type, requestId: id, payload }, (res) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);

      if (chrome.runtime.lastError) {
        console.error("[INFINITY CONTENT] runtime error", chrome.runtime.lastError.message);
        respond(id, false, undefined, {
          code: "UPSTREAM_ERROR",
          message: `Extensão indisponível: ${chrome.runtime.lastError.message}`,
        });
        return;
      }
      if (!res || !res.ok) {
        console.warn("[INFINITY CONTENT] response error", res?.error);
        respond(
          id,
          false,
          undefined,
          res?.error ?? { code: "UPSTREAM_ERROR", message: "Falha ao consultar o Convert+." },
        );
        return;
      }
      console.log("[INFINITY CONTENT] response delivered", type);
      respond(id, true, res.data);
    });
  } catch (err) {
    settled = true;
    clearTimeout(timer);
    console.error("[INFINITY CONTENT] sendMessage falhou", err);
    respond(id, false, undefined, {
      code: "UPSTREAM_ERROR",
      message: `Não foi possível falar com a extensão: ${String(err?.message ?? err)}`,
    });
  }
});

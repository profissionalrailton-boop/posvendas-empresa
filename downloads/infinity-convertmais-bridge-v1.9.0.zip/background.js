// Service worker: roteia ações (getProducts / getPlans) da aba do Infinity para
// a aba autenticada do Convert+ (comunicação ENTRE ABAS via chrome.tabs).
// Nenhum cookie/token é lido, armazenado ou repassado.

const CONVERT_MATCH = "https://www.convertmais.com.br/*";
const ANCORA_HOSTS = new Set([
  "portal-parceiro.ancoraconsorcios.com.br",
  "portal-parceiro-backend.ancoraconsorcios.com.br",
  "gestaocarteira.ancoraconsorcios.com.br",
  "gestaocarteira-backend.ancoraconsorcios.com.br",
]);
const ANCORA_PORTAL_HOSTS = new Set([
  "portal-parceiro.ancoraconsorcios.com.br",
  "gestaocarteira.ancoraconsorcios.com.br",
]);
const CONVERT_URL = "https://www.convertmais.com.br/AdminConvertMais/ConvertMaisWeb/";

console.log("[SERVICE WORKER] iniciado");

function typeFor(action) {
  if (action === "getPlans") return "GET_PLANS";
  if (action === "getGroups") return "GET_GROUPS";
  if (action === "getGroupDetails") return "GET_GROUP_DETAILS";
  return "GET_PRODUCTS";
}

function legacyFor(action) {
  if (action === "getPlans") return "pageGetPlans";
  if (action === "getGroups") return "pageGetGroups";
  if (action === "getGroupDetails") return "pageGetGroupDetails";
  return "pageGetProducts";
}

function logPrefix(action) {
  return typeFor(action);
}

function askTab(tabId, action, payload) {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      resolve({
        ok: false,
        error: { code: "TIMEOUT", message: "A aba do Convert+ não respondeu a tempo." },
      });
    }, 25000);

    const requestId = `sw-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    chrome.tabs.sendMessage(
      tabId,
      {
        bridge: "infinity-convertmais-bridge",
        type: typeFor(action),
        legacyType: legacyFor(action),
        requestId,
        payload,
      },
      (res) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);

        if (chrome.runtime.lastError) {
          console.warn(
            "[SERVICE WORKER] sem content script na aba",
            tabId,
            chrome.runtime.lastError.message,
          );
          resolve({
            ok: false,
            error: {
              code: "NO_SESSION",
              message:
                "A aba do Convert+ não tem a ponte carregada. Recarregue a aba do Convert+ e tente novamente.",
            },
          });
          return;
        }
        resolve(
          res ?? {
            ok: false,
            error: { code: "UPSTREAM_ERROR", message: "Sem resposta da aba do Convert+." },
          },
        );
      },
    );
  });
}

function waitForComplete(tabId, timeoutMs = 20000) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(false);
    }, timeoutMs);
    function listener(id, info) {
      if (id === tabId && info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        // pequena folga para os content scripts registrarem os listeners
        setTimeout(() => resolve(true), 500);
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

/** Garante que os scripts da ponte existam na aba (caso o content script não tenha rodado). */
async function ensureBridgeScripts(tabId) {
  if (!chrome.scripting) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["page-bridge.js"],
      world: "MAIN",
    });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["convert-content.js"],
      world: "ISOLATED",
    });
    console.log("[SERVICE WORKER] scripts da ponte injetados na aba", tabId);
  } catch (err) {
    console.warn("[SERVICE WORKER] injeção de scripts falhou", err?.message ?? err);
  }
}

async function askTabWithRetry(tabId, action, payload) {
  const first = await askTab(tabId, action, payload);
  if (first.ok || first.error?.code !== "NO_SESSION") return first;
  await ensureBridgeScripts(tabId);
  return askTab(tabId, action, payload);
}

async function runOnConvertTab(action, payload) {
  const tabs = await chrome.tabs.query({ url: CONVERT_MATCH });
  console.log("[SERVICE WORKER] abas do Convert+ encontradas:", tabs.length);

  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    console.log("[SERVICE WORKER] Convert+ tab found:", tab.id);
    const res = await askTabWithRetry(tab.id, action, payload);
    if (res.ok) {
      console.log("[SERVICE WORKER] response received da aba", tab.id);
      return res;
    }
    console.warn("[SERVICE WORKER] aba", tab.id, "falhou:", res.error);
    if (res.error?.code === "NO_SESSION") continue;
    return res;
  }

  if (tabs.length > 0) {
    return {
      ok: false,
      error: {
        code: "NO_SESSION",
        message: "Sessão do Convert+ não encontrada. Faça login no Convert+ e tente novamente.",
      },
    };
  }

  console.log("[SERVICE WORKER] nenhuma aba do Convert+, abrindo em segundo plano");
  const tab = await chrome.tabs.create({ url: CONVERT_URL, active: false });
  if (typeof tab.id !== "number") {
    return {
      ok: false,
      error: { code: "NO_SESSION", message: "Abra o Convert+ e faça login para continuar." },
    };
  }
  await waitForComplete(tab.id);
  console.log("[SERVICE WORKER] Convert+ tab found:", tab.id, "(aberta agora)");
  const res = await askTabWithRetry(tab.id, action, payload);
  try {
    await chrome.tabs.remove(tab.id);
  } catch {
    /* ignore */
  }
  return res;
}

/** ---------- Âncora: roteamento para a aba autenticada do portal ---------- */

function askAncoraTab(tabId, payload, type = "ANCORA_API") {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      resolve({
        ok: false,
        error: {
          code: "TIMEOUT",
          message: "A aba da Âncora não respondeu a tempo.",
          action: `${payload?.method ?? "GET"} ${payload?.path ?? ""}`,
        },
      });
    }, 30000);

    chrome.tabs.sendMessage(tabId, { bridge: "infinity-convertmais-bridge", type, payload }, (res) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (chrome.runtime.lastError) {
        resolve({
          ok: false,
          error: {
            code: "UPSTREAM_ERROR",
            message:
              "A aba da Âncora não tem a ponte carregada. Recarregue o portal da Âncora e tente novamente.",
            action: `${payload?.method ?? "GET"} ${payload?.path ?? ""}`,
          },
        });
        return;
      }
      resolve(res ?? { ok: false, error: { code: "UPSTREAM_ERROR", message: "Sem resposta da aba da Âncora." } });
    });
  });
}

async function ensureAncoraScripts(tabId) {
  if (!chrome.scripting) return;
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["ancora-page-bridge.js"], world: "MAIN" });
    await chrome.scripting.executeScript({ target: { tabId }, files: ["ancora-content.js"], world: "ISOLATED" });
    console.log("[SERVICE WORKER] scripts da Âncora injetados na aba", tabId);
  } catch (err) {
    console.warn("[SERVICE WORKER] injeção Âncora falhou", err?.message ?? err);
  }
}

async function askAncoraTabWithRetry(tabId, payload, type) {
  const first = await askAncoraTab(tabId, payload, type);
  if (first.ok || !String(first.error?.message ?? "").includes("ponte carregada")) return first;
  await ensureAncoraScripts(tabId);
  return askAncoraTab(tabId, payload, type);
}

async function runOnAncoraTab(payload, type = "ANCORA_API") {
  console.log("[ANCORA BRIDGE] procurando aba autenticada");
  const allTabs = await chrome.tabs.query({});
  const inspectedTabs = allTabs.map((tab) => ({ id: tab.id, url: tab.url ?? "URL indisponível" }));
  console.log("[ANCORA BRIDGE] abas encontradas", inspectedTabs);
  const tabs = allTabs.filter((tab) => {
    if (!tab.url) return false;
    try {
      return ANCORA_HOSTS.has(new URL(tab.url).hostname);
    } catch {
      return false;
    }
  }).sort((a, b) => {
    const aIsPortal = a.url && ANCORA_PORTAL_HOSTS.has(new URL(a.url).hostname) ? 1 : 0;
    const bIsPortal = b.url && ANCORA_PORTAL_HOSTS.has(new URL(b.url).hostname) ? 1 : 0;
    return bIsPortal - aIsPortal;
  });

  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    console.log("[ANCORA BRIDGE] aba encontrada", tab.id);
    const requestUrl = new URL(payload?.path ?? "/", "https://portal-parceiro-backend.ancoraconsorcios.com.br");
    for (const [key, value] of Object.entries(payload?.query ?? {})) {
      if (value !== undefined && value !== null && value !== "") requestUrl.searchParams.set(key, String(value));
    }
    console.log("[ANCORA BRIDGE] executando chamada no contexto da página");
    console.log("[ANCORA BRIDGE] URL", requestUrl.toString());
    const res = await askAncoraTabWithRetry(tab.id, payload, type);
    if (res.ok) {
      if (typeof res.httpStatus === "number") console.log("[ANCORA BRIDGE] status HTTP", res.httpStatus);
      console.log("[ANCORA BRIDGE] resposta recebida");
      console.log("[ANCORA BRIDGE] ação concluída", payload?.path ?? "", tab.url ?? "");
      return res;
    }
    console.warn("[ANCORA BRIDGE] ação falhou na aba", tab.id, tab.url ?? "", res.error);
    return res;
  }

  console.warn("[ANCORA BRIDGE] nenhuma aba compatível; URLs analisadas", inspectedTabs);
  return {
    ok: false,
    error: {
      code: "NO_ANCORA_TAB",
      message:
        "Nenhuma aba da Âncora foi localizada pelos domínios do portal ou da API. Abra o portal e recarregue a extensão.",
      url: inspectedTabs.map((tab) => tab.url).join(" | "),
      action: `${payload?.method ?? "GET"} ${payload?.path ?? ""}`,
    },
  };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "GET_ANCORA_PRODUCTS") {
    console.log("[ANCORA BRIDGE] products request received");
    runOnAncoraTab(
      { method: "GET", path: "/api/produtos", query: { BusinessUnitId: 1 } },
      "GET_ANCORA_PRODUCTS",
    )
      .then(sendResponse)
      .catch((err) => {
        sendResponse({ ok: false, error: { code: "UPSTREAM_ERROR", message: String(err?.message ?? err) } });
      });
    return true;
  }

  if (message?.type === "GET_ANCORA_ASSETS") {
    console.log("[ANCORA BRIDGE] assets request received");
    runOnAncoraTab(message?.payload, "GET_ANCORA_ASSETS")
      .then(sendResponse)
      .catch((err) => {
        sendResponse({ ok: false, error: { code: "UPSTREAM_ERROR", message: String(err?.message ?? err) } });
      });
    return true;
  }

  if (message?.type === "ANCORA_API") {
    console.log("[SERVICE WORKER] ANCORA_API received", message?.payload?.path ?? "");
    runOnAncoraTab(message?.payload)
      .then((res) => {
        if (!res.ok) console.warn("[SERVICE WORKER] ANCORA_API error:", res.error);
        sendResponse(res);
      })
      .catch((err) => {
        sendResponse({ ok: false, error: { code: "UPSTREAM_ERROR", message: String(err?.message ?? err) } });
      });
    return true;
  }

  const t = message?.type;
  const action =
    t === "getProducts" || t === "GET_PRODUCTS"
      ? "getProducts"
      : t === "getPlans" || t === "GET_PLANS"
        ? "getPlans"
        : t === "getGroups" || t === "GET_GROUPS"
          ? "getGroups"
          : t === "getGroupDetails" || t === "GET_GROUP_DETAILS"
            ? "getGroupDetails"
            : null;
  if (!action) return false;

  console.log(`[SERVICE WORKER] ${logPrefix(action)} received`, message?.requestId ?? "");
  runOnConvertTab(action, message?.payload)
    .then((res) => {
      console.log(`[SERVICE WORKER] ${logPrefix(action)} response received`);
      if (!res.ok) {
        const httpResponse = res.error?.httpResponse;
        if (httpResponse !== undefined && httpResponse !== null) {
          console.warn(`[SERVICE WORKER] ${logPrefix(action)} upstream error:`, httpResponse);
        }
        console.warn(`[SERVICE WORKER] ${logPrefix(action)} error:`, res.error);
      }
      sendResponse(res);
    })
    .catch((err) => {
      console.error("[SERVICE WORKER] erro inesperado", err);
      sendResponse({
        ok: false,
        error: { code: "UPSTREAM_ERROR", message: String(err?.message ?? err) },
      });
    });
  return true; // resposta assíncrona
});

// Content script isolado, rodando nas páginas do Convert+.
// Ponte entre o service worker (chrome.runtime) e o page bridge (MAIN world).

(() => {
  const CHANNEL = "infinity-convertmais-bridge";
  if (window.__infinityConvertContentLoaded) return;
  window.__infinityConvertContentLoaded = true;

  console.log("[CONVERT CONTENT] carregado");

  function normalize(type) {
    if (type === "pageGetProducts" || type === "GET_PRODUCTS" || type === "getProducts") {
      return "getProducts";
    }
    if (type === "pageGetPlans" || type === "GET_PLANS" || type === "getPlans") {
      return "getPlans";
    }
    if (type === "pageGetGroups" || type === "GET_GROUPS" || type === "getGroups") {
      return "getGroups";
    }
    if (
      type === "pageGetGroupDetails" ||
      type === "GET_GROUP_DETAILS" ||
      type === "getGroupDetails"
    ) {
      return "getGroupDetails";
    }
    return null;
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    const action = normalize(message?.type);
    if (!action) return false;
    console.log("[CONVERT CONTENT] request received", action);

    const id = `sw-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    let settled = false;

    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      window.removeEventListener("message", onMessage);
      console.warn("[CONVERT CONTENT] timeout aguardando page bridge");
      sendResponse({
        ok: false,
        error: {
          code: "TIMEOUT",
          message:
            "A página do Convert+ não respondeu. Recarregue a aba do Convert+ e tente novamente.",
        },
      });
    }, 20000);

    function onMessage(event) {
      if (event.source !== window) return;
      const data = event.data;
      if (!data || data.channel !== CHANNEL) return;
      if (data.direction !== "page-response" || data.id !== id) return;
      if (settled) return;

      settled = true;
      clearTimeout(timer);
      window.removeEventListener("message", onMessage);

      const label =
        action === "getPlans"
          ? "GET_PLANS"
          : action === "getProducts"
            ? "GET_PRODUCTS"
            : action === "getGroups"
              ? "GET_GROUPS"
              : "GET_GROUP_DETAILS";

      if (data.ok) {
        console.log("[CONVERT CONTENT] response delivered", label);
        sendResponse({ ok: true, data: data.payload });
        return;
      }

      const error = data.error ?? {
        code: "UPSTREAM_ERROR",
        message: "Falha ao consultar o Convert+.",
      };
      // Erro de aplicação já recebido: entrega imediata, sem esperar timeout.
      console.warn(`[CONVERT CONTENT] ${label} error delivered`, error);
      sendResponse({ ok: false, error });
    }

    window.addEventListener("message", onMessage);
    window.postMessage(
      {
        channel: CHANNEL,
        bridge: CHANNEL,
        direction: "page-request",
        id,
        requestId: id,
        action,
        type:
          action === "getProducts"
            ? "GET_PRODUCTS"
            : action === "getPlans"
              ? "GET_PLANS"
              : action === "getGroupDetails"
                ? "GET_GROUP_DETAILS"
                : "GET_GROUPS",
        payload: message?.payload ?? {},
      },
      window.location.origin,
    );

    return true; // resposta assíncrona
  });
})();

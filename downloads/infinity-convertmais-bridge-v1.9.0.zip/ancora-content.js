// Content script isolado, rodando no portal da Âncora.
// Ponte entre o service worker (chrome.runtime) e o page bridge (MAIN world).

(() => {
  const CHANNEL = "infinity-convertmais-bridge";
  if (window.__infinityAncoraContentLoaded) return;
  window.__infinityAncoraContentLoaded = true;

  console.log("[ANCORA CONTENT] carregado");

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (
      message?.type !== "ANCORA_API" &&
      message?.type !== "GET_ANCORA_PRODUCTS" &&
      message?.type !== "GET_ANCORA_ASSETS"
    ) return false;

    if (message.type === "GET_ANCORA_PRODUCTS") {
      console.log("[ANCORA BRIDGE] products request received");
    }
    if (message.type === "GET_ANCORA_ASSETS") {
      console.log("[ANCORA BRIDGE] assets request received");
    }

    console.log(
      "[ANCORA CONTENT] request received",
      message?.payload?.method ?? "GET",
      message?.payload?.path ?? "",
    );

    const id = `sw-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    let settled = false;

    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      window.removeEventListener("message", onMessage);
      sendResponse({
        ok: false,
        error: {
          code: "TIMEOUT",
          message: "O portal da Âncora não respondeu. Recarregue a aba da Âncora e tente de novo.",
          url: window.location.href,
          action: message?.payload?.path ?? "ANCORA_API",
        },
      });
    }, 25000);

    function onMessage(event) {
      if (event.source !== window) return;
      const data = event.data;
      if (!data || data.channel !== CHANNEL) return;
      if (data.direction !== "ancora-page-response" || data.id !== id) return;
      if (settled) return;

      settled = true;
      clearTimeout(timer);
      window.removeEventListener("message", onMessage);

      if (data.ok) {
        sendResponse({
          ok: true,
          data: data.payload,
          ...(typeof data.httpStatus === "number" ? { httpStatus: data.httpStatus } : {}),
        });
        return;
      }
      console.warn("[ANCORA CONTENT] erro entregue", data.error);
      sendResponse({
        ok: false,
        error: data.error ?? { code: "UPSTREAM_ERROR", message: "Falha na API da Âncora." },
      });
    }

    window.addEventListener("message", onMessage);
    window.postMessage(
      {
        channel: CHANNEL,
        direction: "ancora-page-request",
        id,
        type: message.type,
        payload: message?.payload ?? {},
      },
      window.location.origin,
    );

    return true; // resposta assíncrona
  });
})();

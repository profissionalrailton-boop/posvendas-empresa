// Page script (MAIN world) — roda dentro do portal da Âncora já autenticado.
// A requisição é executada pelo PRÓPRIO mecanismo de rede da aplicação
// (instância Axios com o interceptor oficial, ou o replay do pipeline XHR
// usado pelo portal). Nenhum token é lido, logado, copiado ou persistido.

(() => {
  const CHANNEL = "infinity-convertmais-bridge";
  // A Âncora migrou o portal: gestaocarteira → portal-parceiro (cada um com seu backend).
  const ANCORA_BACKENDS = [
    "https://portal-parceiro-backend.ancoraconsorcios.com.br",
    "https://gestaocarteira-backend.ancoraconsorcios.com.br",
  ];
  const API_BASE = window.location.hostname.startsWith("gestaocarteira")
    ? "https://gestaocarteira-backend.ancoraconsorcios.com.br"
    : "https://portal-parceiro-backend.ancoraconsorcios.com.br";

  if (window.__infinityAncoraPageBridgeLoaded) return;
  window.__infinityAncoraPageBridgeLoaded = true;

  console.log("[ANCORA PAGE BRIDGE] carregado");

  // ---------------------------------------------------------------------
  // Mecanismo 1: instância Axios real da aplicação (com interceptor oficial)
  // ---------------------------------------------------------------------

  const axiosCandidates = new Set();
  let verifiedAssetsAxiosInstance = null;
  let verifiedAssetsRequestProfile = null;
  let verifiedAssetsRequestShape = null;

  function isAssetsRequestConfig(config) {
    try {
      const rawUrl = String(config?.url ?? "");
      const url = new URL(rawUrl, String(config?.baseURL ?? API_BASE));
      return url.pathname === "/api/bens/seleciona";
    } catch {
      return false;
    }
  }

  function resolvedAxiosUrl(instance, config) {
    try {
      if (typeof instance?.getUri === "function") return instance.getUri(config);
    } catch {
      // Cai na composição padrão abaixo.
    }
    try {
      return new URL(String(config?.url ?? ""), String(config?.baseURL ?? instance?.defaults?.baseURL ?? API_BASE)).toString();
    } catch {
      return "";
    }
  }

  function captureAssetsRequestShape(instance, config) {
    const resolvedUrl = resolvedAxiosUrl(instance, config);
    let pathname = "";
    try {
      pathname = new URL(resolvedUrl).pathname;
    } catch {
      pathname = "";
    }
    if (pathname !== "/api/bens/seleciona") return false;
    // Preserva toda a configuração não sensível que chegou ao adapter na
    // chamada HTTP 200 real. Headers/auth NÃO são copiados: ao repetir pela
    // mesma instância, o interceptor oficial os produz novamente.
    const replayConfig = {};
    const excludedKeys = new Set([
      "headers",
      "auth",
      "params",
      "data",
      "url",
      "method",
      "baseURL",
      "paramsSerializer",
      "signal",
      "cancelToken",
    ]);
    for (const key of Reflect.ownKeys(config ?? {})) {
      if (typeof key === "string" && excludedKeys.has(key)) continue;
      try {
        replayConfig[key] = config[key];
      } catch {
        // Propriedade interna inacessível; defaults da instância serão usados.
      }
    }
    verifiedAssetsRequestShape = {
      ...replayConfig,
      // O endpoint é armazenado sem query. A chamada repetida recebe os três
      // parâmetros uma única vez via `params`, evitando duplicação quando a
      // URL original do portal já veio com query string embutida.
      url: "/api/bens/seleciona",
      baseURL: config?.baseURL ?? instance?.defaults?.baseURL,
      method: String(config?.method ?? "GET").toUpperCase(),
    };
    return true;
  }

  function safeHeaderMetadata(headers) {
    let names = [];
    try {
      if (typeof headers?.toJSON === "function") {
        names = Object.keys(headers.toJSON());
      } else if (headers && typeof headers === "object") {
        names = Object.keys(headers);
      }
    } catch {
      names = [];
    }
    const normalized = [...new Set(names.map((name) => String(name).toLowerCase()))].sort();
    const standard = new Set(["accept", "authorization", "content-type", "cookie", "origin", "referer", "user-agent"]);
    return {
      authPresent: normalized.includes("authorization"),
      contentTypePresent: normalized.includes("content-type"),
      acceptPresent: normalized.includes("accept"),
      headerNames: normalized,
      customHeaders: normalized.filter((name) => !standard.has(name)),
    };
  }

  function logAssetsDebug(side, metadata) {
    console.log(`[ANCORA DEBUG] ${side} request method: ${metadata.method}`);
    console.log(`[ANCORA DEBUG] ${side} request URL matched: ${metadata.urlMatched}`);
    console.log(`[ANCORA DEBUG] ${side} auth present: ${metadata.authPresent}`);
    console.log(`[ANCORA DEBUG] ${side} custom headers:`, metadata.customHeaders);
    console.log(`[ANCORA DEBUG] ${side} origin present: ${metadata.originPresent}`);
    console.log(`[ANCORA DEBUG] ${side} referer present: ${metadata.refererPresent}`);
    console.log(`[ANCORA DEBUG] ${side} cookies present: ${metadata.cookiesPresent}`);
    console.log(`[ANCORA DEBUG] ${side} content-type present: ${metadata.contentTypePresent}`);
    console.log(`[ANCORA DEBUG] ${side} accept present: ${metadata.acceptPresent}`);
    console.log(`[ANCORA DEBUG] ${side} user-agent present: ${metadata.userAgentPresent}`);
    console.log(`[ANCORA DEBUG] request mechanism: ${metadata.mechanism}`);
    console.log(`[ANCORA DEBUG] initiator identified: ${metadata.initiatorIdentified}`);
  }

  /**
   * Interceptor de request instalado uma única vez por instância Axios.
   * Só toca em requisições marcadas como bens da ponte (__infinityAssetsBridgeRequest):
   * remove accept-version e força Accept: application/json, espelhando a chamada
   * real do portal. Nenhuma outra chamada (portal, Convert+, produtos) é afetada.
   */
  function normalizeAssetsHeaders(config) {
    if (!config?.__infinityAssetsBridgeRequest) return config;
    const headers = config.headers;
    const drop = ["accept-version", "Accept-Version", "acceptVersion"];
    if (headers && typeof headers.delete === "function") {
      drop.forEach((key) => headers.delete(key));
      headers.set("Accept", "application/json");
    } else if (headers && typeof headers === "object") {
      drop.forEach((key) => {
        delete headers[key];
        if (headers.common) delete headers.common[key];
        if (headers.get) delete headers.get[key];
      });
      delete headers["accept"];
      headers["Accept"] = "application/json";
    }
    const finalHeaders = config.headers ?? {};
    const hasAcceptVersion =
      typeof finalHeaders.has === "function"
        ? finalHeaders.has("accept-version")
        : Object.keys(finalHeaders).some((k) => k.toLowerCase() === "accept-version");
    console.log("[ANCORA DEBUG] GET /api/bens/seleciona");
    console.log("[ANCORA DEBUG] Accept: application/json");
    console.log(`[ANCORA DEBUG] accept-version present: ${Boolean(hasAcceptVersion)}`);
    return config;
  }

  function installAssetsHeaderNormalizer(instance) {
    if (!instance || instance.__infinityAssetsHeaderNormalizer) return;
    instance.__infinityAssetsHeaderNormalizer = true;

    if (typeof instance.interceptors?.request?.use === "function") {
      instance.interceptors.request.use(normalizeAssetsHeaders);
    }

    // O adapter roda depois de TODOS os interceptors do portal, garantindo que
    // um interceptor da própria aplicação não reintroduza accept-version.
    const baseAdapter = instance.defaults?.adapter;
    if (typeof baseAdapter === "function" && !baseAdapter.__infinityAssetsAdapter) {
      const wrapped = (config) => {
        normalizeAssetsHeaders(config);
        return baseAdapter(config);
      };
      wrapped.__infinityAssetsAdapter = true;
      instance.defaults.adapter = wrapped;
    }
  }



  function assetsRequestProfile(instance, config, mechanism = "axios") {
    const headers = safeHeaderMetadata(config?.headers);
    const resolvedUrl = resolvedAxiosUrl(instance, config);
    let parsedUrl = null;
    try {
      parsedUrl = new URL(resolvedUrl);
    } catch {
      parsedUrl = null;
    }
    return {
      method: String(config?.method ?? "GET").toUpperCase(),
      urlMatched: parsedUrl?.pathname === "/api/bens/seleciona",
      queryMatched:
        parsedUrl?.searchParams.get("ProductId") === "1" &&
        parsedUrl?.searchParams.get("InitialAssetValue") === "10000" &&
        parsedUrl?.searchParams.get("FinalAssetValue") === "200000",
      mechanism,
      initiatorIdentified: true,
      originPresent: Boolean(window.location.origin),
      refererPresent: Boolean(document.referrer || window.location.href),
      // Cookies são geridos pelo navegador e não são lidos. withCredentials
      // confirma apenas que o envio de credenciais está habilitado.
      cookiesPresent: config?.withCredentials === true,
      userAgentPresent: Boolean(navigator.userAgent),
      ...headers,
    };
  }

  function logAssetsComparison(extensionProfile) {
    const portal = verifiedAssetsRequestProfile;
    if (!portal) return;
    console.log("[ANCORA DEBUG] portal vs extension comparison", {
      methodMatched: portal.method === extensionProfile.method,
      urlMatched: portal.urlMatched === extensionProfile.urlMatched,
      queryMatched: portal.queryMatched === extensionProfile.queryMatched,
      authorizationPresenceMatched: portal.authPresent === extensionProfile.authPresent,
      cookieModeMatched: portal.cookiesPresent === extensionProfile.cookiesPresent,
      originPresenceMatched: portal.originPresent === extensionProfile.originPresent,
      refererPresenceMatched: portal.refererPresent === extensionProfile.refererPresent,
      acceptPresenceMatched: portal.acceptPresent === extensionProfile.acceptPresent,
      contentTypePresenceMatched:
        portal.contentTypePresent === extensionProfile.contentTypePresent,
      mechanismMatched: portal.mechanism === extensionProfile.mechanism,
      initiatorIdentified: extensionProfile.initiatorIdentified,
      customHeaderNamesMatched:
        JSON.stringify(portal.customHeaders) === JSON.stringify(extensionProfile.customHeaders),
    });
  }

  function isAxiosInstance(value) {
    if ((typeof value !== "function" && typeof value !== "object") || value === null) return false;
    try {
      return typeof value.request === "function" &&
        typeof value.get === "function" &&
        Boolean(value.interceptors?.request) &&
        Array.isArray(value.interceptors.request.handlers);
    } catch {
      return false;
    }
  }

  function hasRequestInterceptor(instance) {
    try {
      return Boolean(
        instance?.interceptors?.request?.handlers?.some(
          (h) => h && typeof h.fulfilled === "function",
        ),
      );
    } catch {
      return false;
    }
  }

  function targetsAncoraBackend(instance) {
    const baseURL = String(instance?.defaults?.baseURL ?? "").replace(/\/$/, "");
    return ANCORA_BACKENDS.includes(baseURL) || baseURL === "";
  }

  function registerAxiosCandidate(value) {
    if (!isAxiosInstance(value)) return;
    axiosCandidates.add(value);
    if (value.__infinityAssetsObserverInstalled) return;
    value.__infinityAssetsObserverInstalled = true;
    value.interceptors.response.use(
      (response) => {
        if (response?.config?.__infinityAssetsBridgeRequest) return response;
        if (Number(response?.status) !== 200 || !captureAssetsRequestShape(value, response?.config)) return response;
        verifiedAssetsAxiosInstance = value;
        verifiedAssetsRequestProfile = assetsRequestProfile(value, response.config);
        logAssetsDebug("portal", verifiedAssetsRequestProfile);
        return response;
      },
      (error) => Promise.reject(error),
    );
  }

  /** Registra instâncias criadas pela aplicação, sem tocar no interceptor. */
  function wrapAxiosModule(exports) {
    try {
      const candidates = [exports, exports?.default];
      for (const mod of candidates) {
        if (!mod || (typeof mod !== "function" && typeof mod !== "object")) continue;
        if (typeof mod.create !== "function" || !mod.interceptors) continue;
        if (mod.__infinityAncoraWrapped) continue;
        mod.__infinityAncoraWrapped = true;
        registerAxiosCandidate(mod);
        const originalCreate = mod.create.bind(mod);
        mod.create = function (...args) {
          const instance = originalCreate(...args);
          registerAxiosCandidate(instance);
          return instance;
        };
        const Axios = mod.Axios;
        if (Axios?.prototype?.request && !Axios.prototype.__infinityAncoraWrapped) {
          Axios.prototype.__infinityAncoraWrapped = true;
          const originalRequest = Axios.prototype.request;
          Axios.prototype.request = function (...args) {
            registerAxiosCandidate(this);
            const config = typeof args[0] === "string" ? { ...(args[1] ?? {}), url: args[0] } : (args[0] ?? {});
            const tracksAssets = isAssetsRequestConfig(config);
            const result = originalRequest.apply(this, args);
            if (tracksAssets && result && typeof result.then === "function") {
              result.then(
                (response) => {
                  if (response?.config?.__infinityAssetsBridgeRequest) return;
                  if (Number(response?.status) !== 200 || !captureAssetsRequestShape(this, response?.config ?? config)) return;
                  const finalConfig = response?.config ?? config;
                  verifiedAssetsAxiosInstance = this;
                  verifiedAssetsRequestProfile = assetsRequestProfile(this, finalConfig);
                  logAssetsDebug("portal", verifiedAssetsRequestProfile);
                },
                () => undefined,
              );
            }
            return result;
          };
        }
        console.log("[ANCORA BRIDGE] portal request mechanism found: axios module");
      }
    } catch {
      // Módulo inspecionável; ignora silenciosamente.
    }
  }

  /** Intercepta o registro de chunks do bundler para achar o módulo axios. */
  function hookWebpackChunks() {
    const hookArray = (arr) => {
      if (!Array.isArray(arr) || arr.__infinityAncoraHooked) return;
      arr.__infinityAncoraHooked = true;
      const originalPush = arr.push.bind(arr);
      arr.push = function (chunk) {
        try {
          const modules = chunk?.[1];
          if (modules && typeof modules === "object") {
            for (const key of Object.keys(modules)) {
              const factory = modules[key];
              if (typeof factory !== "function" || factory.__infinityAncoraWrapped) continue;
              const wrapped = function (module, exports, req) {
                const result = factory.call(this, module, exports, req);
                wrapAxiosModule(module?.exports ?? exports);
                return result;
              };
              wrapped.__infinityAncoraWrapped = true;
              modules[key] = wrapped;
            }
          }
        } catch {
          // Chunk fora do formato esperado; segue sem interferir.
        }
        return originalPush(chunk);
      };
    };

    for (const key of Object.getOwnPropertyNames(window)) {
      if (key.startsWith("webpackChunk") || key.startsWith("webpackJsonp")) hookArray(window[key]);
    }

    // Chunks registrados depois do document_start.
    const seen = new Set(Object.getOwnPropertyNames(window));
    const interval = setInterval(() => {
      for (const key of Object.getOwnPropertyNames(window)) {
        if (seen.has(key)) continue;
        seen.add(key);
        if (key.startsWith("webpackChunk") || key.startsWith("webpackJsonp")) hookArray(window[key]);
      }
    }, 300);
    setTimeout(() => clearInterval(interval), 30000);
  }

  hookWebpackChunks();

  function inspectReactRuntime(root) {
    const visited = new WeakSet();
    const queue = [root];
    let inspected = 0;
    while (queue.length > 0 && inspected < 100000) {
      const value = queue.shift();
      if (value === null || value === undefined) continue;
      if (typeof value !== "object" && typeof value !== "function") continue;
      if (visited.has(value)) continue;
      visited.add(value);
      inspected += 1;
      if (isAxiosInstance(value) && hasRequestInterceptor(value) && targetsAncoraBackend(value)) {
        return value;
      }
      for (const key of ["current", "memoizedState", "child", "sibling", "next", "alternate"]) {
        try {
          const nested = value[key];
          if (nested !== null && nested !== undefined) queue.push(nested);
        } catch {
          // Propriedade interna inacessível.
        }
      }
    }
    return null;
  }

  function findPortalAxiosInstance() {
    for (const instance of axiosCandidates) {
      if (hasRequestInterceptor(instance) && targetsAncoraBackend(instance)) return instance;
    }

    const nodes = [document.documentElement, ...document.querySelectorAll("body *")];
    for (const node of nodes) {
      const reactKey = Object.getOwnPropertyNames(node).find(
        (key) => key.startsWith("__reactFiber$") || key.startsWith("__reactContainer$"),
      );
      if (!reactKey) continue;
      const instance = inspectReactRuntime(node[reactKey]);
      if (instance) {
        registerAxiosCandidate(instance);
        return instance;
      }
    }
    return null;
  }

  // ---------------------------------------------------------------------
  // Mecanismo 2: replay do pipeline de rede autenticado da própria página
  // Os headers da aplicação são repassados direto de setRequestHeader para
  // setRequestHeader, dentro do MAIN world. Nada é lido, logado ou guardado
  // fora da página autenticada.
  // ---------------------------------------------------------------------

  let portalRequestReplayer = null;

  function isAncoraBackendUrl(value) {
    try {
      const url = new URL(String(value), window.location.href);
      return ANCORA_BACKENDS.some((b) => new URL(b).hostname === url.hostname);
    } catch {
      return false;
    }
  }

  function installPortalRequestCapture() {
    if (window.__infinityAncoraCaptureLoaded) return;
    window.__infinityAncoraCaptureLoaded = true;

    const OriginalXHR = window.XMLHttpRequest;
    const originalOpen = OriginalXHR.prototype.open;
    const originalSetRequestHeader = OriginalXHR.prototype.setRequestHeader;
    const originalSend = OriginalXHR.prototype.send;

    OriginalXHR.prototype.open = function (method, url, ...rest) {
      this.__ancoraTracked = isAncoraBackendUrl(url);
      this.__ancoraMethod = String(method ?? "GET").toUpperCase();
      this.__ancoraUrl = String(url ?? "");
      this.__ancoraInitiatorIdentified = Boolean(new Error().stack);
      this.__ancoraHeaders = [];
      return originalOpen.call(this, method, url, ...rest);
    };

    OriginalXHR.prototype.setRequestHeader = function (name, value) {
      if (this.__ancoraTracked && !this.__ancoraBridgeRequest) {
        this.__ancoraHeaders.push([name, value]);
      }
      return originalSetRequestHeader.call(this, name, value);
    };

    OriginalXHR.prototype.send = function (...args) {
      if (this.__ancoraTracked && !this.__ancoraBridgeRequest) {
        const headerEntries = this.__ancoraHeaders.slice();
        const headerNames = headerEntries.map(([name]) => String(name).toLowerCase());
        console.log(
          `[ANCORA AUTH] portal request headers: ${headerNames.join(", ") || "(nenhum)"}`,
        );
        let isAssetsRequest = false;
        try {
          isAssetsRequest = new URL(this.__ancoraUrl, window.location.href).pathname === "/api/bens/seleciona";
        } catch {
          isAssetsRequest = false;
        }
        if (isAssetsRequest) {
          const headers = safeHeaderMetadata(Object.fromEntries(headerEntries));
          logAssetsDebug("portal", {
            method: this.__ancoraMethod,
            urlMatched: true,
            mechanism: "xhr",
            initiatorIdentified: this.__ancoraInitiatorIdentified,
            originPresent: Boolean(window.location.origin),
            refererPresent: Boolean(document.referrer || window.location.href),
            cookiesPresent: Boolean(document.cookie),
            userAgentPresent: Boolean(navigator.userAgent),
            ...headers,
          });
        }
        // Fecha os headers da aplicação num closure do MAIN world; o valor
        // nunca é lido pela ponte, apenas reencaminhado ao mesmo pipeline.
        portalRequestReplayer = ({ url: targetUrl, method = "GET", body }) =>
          new Promise((resolve, reject) => {
            const xhr = new OriginalXHR();
            xhr.__ancoraBridgeRequest = true;
            xhr.open(method, targetUrl, true);
            xhr.withCredentials = true;
            for (const [name, value] of headerEntries) {
              try {
                // Content-Type é definido pelo corpo desta chamada, não pelo replay.
                if (String(name).toLowerCase() === "content-type") continue;
                xhr.setRequestHeader(name, value);
              } catch {
                // Header proibido pelo browser; ignorado.
              }
            }
            if (body !== undefined && body !== null) {
              try {
                xhr.setRequestHeader("Content-Type", "application/json");
              } catch {
                // ignorado
              }
            }
            xhr.timeout = 20000;
            xhr.onload = () => resolve({ status: xhr.status, text: xhr.responseText });
            xhr.onerror = () => reject(new Error("NETWORK_ERROR"));
            xhr.ontimeout = () => reject(new Error("TIMEOUT"));
            xhr.send(body === undefined || body === null ? undefined : JSON.stringify(body));
          });
        this.addEventListener(
          "loadend",
          () => console.log(`[ANCORA AUTH] portal request status: ${this.status}`),
          { once: true },
        );
      }
      return originalSend.apply(this, args);
    };

  }

  installPortalRequestCapture();

  async function waitForMechanism(timeoutMs = 12000) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeoutMs) {
      const instance = findPortalAxiosInstance();
      if (instance) return { kind: "axios", instance };
      if (portalRequestReplayer) return { kind: "xhr-replay" };
      await new Promise((resolve) => setTimeout(resolve, 200));
    }
    return null;
  }

  async function waitForPortalAxios(timeoutMs = 12000) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeoutMs) {
      const instance = findPortalAxiosInstance();
      if (instance) return instance;
      await new Promise((resolve) => setTimeout(resolve, 200));
    }
    return null;
  }

  function reply(id, ok, payload, error, httpStatus) {
    window.postMessage(
      {
        channel: CHANNEL,
        direction: "ancora-page-response",
        id,
        ok,
        payload,
        error,
        ...(typeof httpStatus === "number" ? { httpStatus } : {}),
      },
      window.location.origin,
    );
  }

  function buildUrl(path, query) {
    const url = new URL(path.startsWith("/") ? path : `/${path}`, API_BASE);
    for (const [key, value] of Object.entries(query ?? {})) {
      if (value === undefined || value === null || value === "") continue;
      url.searchParams.set(key, String(value));
    }
    return url.toString();
  }

  /**
   * Query string de bens montada MANUALMENTE na ordem exata da requisição
   * HTTP 200 real do portal: FinalAssetValue, InitialAssetValue, ProductId.
   * Não usar objeto/params serializados — a ordem seria alterada.
   */
  function buildAssetsPathWithQuery(query) {
    const q = query ?? {};
    return (
      "/api/bens/seleciona" +
      `?FinalAssetValue=${encodeURIComponent(String(q.FinalAssetValue))}` +
      `&InitialAssetValue=${encodeURIComponent(String(q.InitialAssetValue))}` +
      `&ProductId=${encodeURIComponent(String(q.ProductId))}`
    );
  }


  function errorDetails(code, message, url, action, httpStatus) {
    return {
      code,
      message,
      url,
      action,
      ...(typeof httpStatus === "number" ? { httpStatus } : {}),
    };
  }

  function payloadCount(payload) {
    if (Array.isArray(payload)) return payload.length;
    if (!payload || typeof payload !== "object") return 0;
    for (const key of ["data", "items", "result", "produtos"]) {
      if (Array.isArray(payload[key])) return payload[key].length;
    }
    return 0;
  }

  async function getAncoraProducts() {
    const url = buildUrl("/api/produtos", { BusinessUnitId: 1 });
    console.log("[ANCORA BRIDGE] request received");
    console.log("[ANCORA BRIDGE] executing inside Ancora page");

    const mechanism = await waitForMechanism();
    if (!mechanism) {
      console.warn("[ANCORA BRIDGE] unable to execute authenticated page request");
      console.warn(
        "[ANCORA BRIDGE] motivo: nenhuma instância Axios da aplicação nem requisição autenticada do portal foi observada nesta aba.",
      );
      return {
        ok: false,
        error: errorDetails(
          "AUTH_ERROR",
          "Não foi possível usar o mecanismo autenticado do portal. Abra o portal da Âncora já logado, navegue até uma tela que carregue produtos e tente novamente.",
          url,
          "GET_ANCORA_PRODUCTS",
        ),
      };
    }

    console.log(`[ANCORA BRIDGE] portal request mechanism found: ${mechanism.kind}`);

    try {
      if (mechanism.kind === "axios") {
        const response = await mechanism.instance.get("/api/produtos", {
          baseURL: API_BASE,
          params: { BusinessUnitId: 1 },
        });
        console.log(`[ANCORA BRIDGE] products response status: ${response.status}`);
        console.log(`[ANCORA BRIDGE] products received: ${payloadCount(response.data)}`);
        return { ok: true, payload: response.data };
      }

      const res = await portalRequestReplayer({ url, method: "GET" });
      console.log(`[ANCORA BRIDGE] products response status: ${res.status}`);
      if (res.status === 401 || res.status === 403) {
        return {
          ok: false,
          error: errorDetails(
            "AUTH_ERROR",
            `A API da Âncora recusou a autenticação (HTTP ${res.status}). Recarregue o portal da Âncora e refaça o login.`,
            url,
            "GET_ANCORA_PRODUCTS",
            res.status,
          ),
        };
      }
      if (res.status < 200 || res.status >= 300) {
        return {
          ok: false,
          error: errorDetails(
            "HTTP_ERROR",
            `A API da Âncora retornou HTTP ${res.status}.`,
            url,
            "GET_ANCORA_PRODUCTS",
            res.status,
          ),
        };
      }
      const payload = res.text?.trim() ? JSON.parse(res.text) : null;
      console.log(`[ANCORA BRIDGE] products received: ${payloadCount(payload)}`);
      return { ok: true, payload };
    } catch (err) {
      const status = Number(err?.response?.status) || undefined;
      if (status) console.log(`[ANCORA BRIDGE] products response status: ${status}`);
      const code = status === 401 || status === 403
        ? "AUTH_ERROR"
        : err?.message === "TIMEOUT" || err?.code === "ECONNABORTED"
          ? "TIMEOUT"
          : status
            ? "HTTP_ERROR"
            : "NETWORK_ERROR";
      console.warn("[ANCORA BRIDGE] unable to execute authenticated page request");
      console.warn(`[ANCORA BRIDGE] motivo: ${code}`);
      return {
        ok: false,
        error: errorDetails(
          code,
          status
            ? `A API da Âncora retornou HTTP ${status}.`
            : code === "TIMEOUT"
              ? "Tempo esgotado ao chamar a API da Âncora."
              : "Falha de rede ao chamar a API da Âncora.",
          url,
          "GET_ANCORA_PRODUCTS",
          status,
        ),
      };
    }
  }



  /** Rótulo curto do endpoint, usado só nos logs. */
  function logLabel(path) {
    if (path.includes("intervalo-valor-bem")) return "interval-value";
    if (path.includes("cria-tabela")) return "create-table";
    if (path.includes("bens/seleciona")) return "assets";
    return path;
  }

  /** Logs de parâmetros (nunca tokens/cookies/Authorization). */
  function logRequestParams(label, query) {
    if (label !== "assets") return;
    const q = query ?? {};
    console.log(`[ANCORA BRIDGE] ProductId: ${q.ProductId ?? ""}`);
    console.log(`[ANCORA BRIDGE] InitialAssetValue: ${q.InitialAssetValue ?? ""}`);
    console.log(`[ANCORA BRIDGE] FinalAssetValue: ${q.FinalAssetValue ?? ""}`);
  }

  function countItems(data) {
    if (Array.isArray(data)) return data.length;
    if (data && typeof data === "object") {
      for (const key of ["data", "items", "result", "records"]) {
        if (Array.isArray(data[key])) return data[key].length;
      }
    }
    return 0;
  }

  async function callApi(payload) {
    const p = payload ?? {};
    const path = String(p.path ?? "");
    if (!path.startsWith("/api/")) {
      return {
        ok: false,
        error: { code: "UPSTREAM_ERROR", message: "Caminho de API inválido." },
      };
    }

    const method = String(p.method ?? "GET").toUpperCase();
    const requestQuery = p.query;
    if (path === "/api/bens/seleciona") {
      const pid = Number(requestQuery?.ProductId);
      if (!Number.isFinite(pid) || pid <= 0) {
        console.warn("[ANCORA BRIDGE] ProductId ausente na requisição de bens");
        return {
          ok: false,
          error: {
            code: "UPSTREAM_ERROR",
            message: "Produto sem ID: selecione um produto válido antes de buscar os créditos.",
          },
        };
      }
    }
    const isAssets = path === "/api/bens/seleciona";
    // Bens: caminho + query montados manualmente na ordem exata do portal.
    const requestPath = isAssets ? buildAssetsPathWithQuery(requestQuery) : path;
    const url = isAssets ? `${API_BASE}${requestPath}` : buildUrl(path, requestQuery);
    const action = `${method} ${path}`;
    const label = logLabel(path);


    console.log(`[ANCORA BRIDGE] ${label} request`);
    logRequestParams(label, requestQuery);

    // Bens sempre usam a instância Axios autenticada da própria aplicação.
    // O request nasce no MAIN world da aba do portal e percorre os interceptors
    // oficiais antes de o adapter Axios disparar XMLHttpRequest. Não há fetch
    // externo, cópia de headers, leitura de token ou fallback fora da página.
    const portalAxios = label === "assets" ? await waitForPortalAxios() : null;
    const mechanism = label === "assets"
      ? (portalAxios ? { kind: "axios", instance: portalAxios } : null)
      : await waitForMechanism();
    if (!mechanism) {
      console.warn(`[ANCORA BRIDGE] ${label} auth error`);
      return {
        ok: false,
        error: errorDetails(
          "AUTH_ERROR",
          "Não foi possível usar o mecanismo autenticado do portal. Abra o portal da Âncora já logado, navegue por uma tela que carregue dados e tente novamente.",
          url,
          action,
        ),
      };
    }

    console.log(`[ANCORA BRIDGE] portal request mechanism found: ${mechanism.kind}`);
    if (label === "assets") {
      console.log("[ANCORA BRIDGE] executando chamada no contexto da página");
      console.log(`[ANCORA BRIDGE] GET /api/bens/seleciona`);
      console.log(`[ANCORA] GET_ANCHOR_ASSETS URL: ${url}`);
      console.log(`[ANCORA BRIDGE] URL ${url}`);
      // Paridade de headers com a chamada real do portal, isolada apenas para bens.
      installAssetsHeaderNormalizer(mechanism.instance);
    }

    let status;
    let data;
    let extensionRequestConfig = null;
    try {
      if (mechanism.kind === "axios") {
        const response = await mechanism.instance.request({
          url: requestPath,
          method,
          baseURL: API_BASE,
          // Bens: a query já está embutida na URL na ordem exata do portal.
          ...(isAssets ? { params: undefined } : { params: requestQuery ?? {} }),
          ...(label === "assets"
            ? {
                __infinityAssetsBridgeRequest: true,
                headers: { Accept: "application/json" },
              }
            : {}),
          ...(p.body === undefined || p.body === null ? {} : { data: p.body }),
        });


        status = response.status;
        data = response.data;
        extensionRequestConfig = response.config ?? null;
        if (label === "assets") {
          console.log(`[ANCORA BRIDGE] status: ${status}`);
          const received = Array.isArray(data)
            ? data.length
            : Array.isArray(data?.data)
              ? data.data.length
              : 0;
          console.log(`[ANCORA BRIDGE] assets received: ${received}`);
        }
      } else {
        const res = await portalRequestReplayer({ url, method, body: p.body });
        status = res.status;
        if (status >= 200 && status < 300) {
          data = res.text?.trim() ? JSON.parse(res.text) : null;
        }
      }
    } catch (err) {
      const errStatus = Number(err?.response?.status) || undefined;
      if (label === "assets" && err?.response?.config) {
        const failedProfile = assetsRequestProfile(mechanism.instance, err.response.config);
        logAssetsDebug("extension", failedProfile);
        logAssetsComparison(failedProfile);
      }
      if (errStatus) {
        console.log(`[ANCORA BRIDGE] ${label} response status: ${errStatus}`);
        if (errStatus === 401 || errStatus === 403) {
          console.warn(`[ANCORA BRIDGE] ${label} auth error`);
          return {
            ok: false,
            error: errorDetails(
              "AUTH_ERROR",
              `A API da Âncora recusou a autenticação (HTTP ${errStatus}).`,
              url,
              action,
              errStatus,
            ),
          };
        }
        if (label === "assets" && errStatus === 404) {
          console.warn("[ANCORA DEBUG] assets mismatch detail", {
            portalResolvedUrlMatched: Boolean(verifiedAssetsRequestProfile?.urlMatched),
            portalMethod: verifiedAssetsRequestProfile?.method ?? "unknown",
            extensionMethod: method,
            extensionPathMatched: path === "/api/bens/seleciona",
            queryNames: Object.keys(requestQuery ?? {}).sort(),
            httpStatus: errStatus,
          });
          return {
            ok: false,
            error: errorDetails(
              "UPSTREAM_REQUEST_MISMATCH",
              "A chamada de bens do Radar divergiu da requisição HTTP 200 observada no portal (HTTP 404). O resultado não foi interpretado como lista vazia.",
              url,
              action,
              errStatus,
            ),
          };
        }
        return {
          ok: false,
          error: errorDetails(
            "HTTP_ERROR",
            `A API da Âncora retornou HTTP ${errStatus} em ${url}.`,
            url,
            action,
            errStatus,
          ),
        };
      }
      const timedOut = err?.message === "TIMEOUT" || err?.code === "ECONNABORTED";
      console.warn(`[ANCORA BRIDGE] ${label} ${timedOut ? "timeout" : "network error"}`);
      return {
        ok: false,
        error: errorDetails(
          timedOut ? "TIMEOUT" : "NETWORK_ERROR",
          timedOut
            ? `Tempo esgotado ao chamar ${url}.`
            : `Falha de rede ao chamar ${url}.`,
          url,
          action,
        ),
      };
    }

    console.log(`[ANCORA BRIDGE] ${label} response status: ${status}`);
    if (label === "assets") console.log(`[ANCORA BRIDGE] status HTTP ${status}`);
    if (label === "assets") {
      const extensionProfile = assetsRequestProfile(
        mechanism.instance,
        extensionRequestConfig ?? { url: path, baseURL: API_BASE, params: requestQuery },
      );
      logAssetsDebug("extension", extensionProfile);
      logAssetsComparison(extensionProfile);
    }

    if (status === 401 || status === 403) {
      console.warn(`[ANCORA BRIDGE] ${label} auth error`);
      return {
        ok: false,
        error: errorDetails(
          "AUTH_ERROR",
          `A API da Âncora recusou a autenticação (HTTP ${status}).`,
          url,
          action,
          status,
        ),
      };
    }

    if (status < 200 || status >= 300) {
      if (label === "assets" && status === 404) {
        console.warn("[ANCORA DEBUG] assets mismatch detail", {
          portalResolvedUrlMatched: Boolean(verifiedAssetsRequestProfile?.urlMatched),
          portalMethod: verifiedAssetsRequestProfile?.method ?? "unknown",
          extensionMethod: method,
          extensionPathMatched: path === "/api/bens/seleciona",
          queryNames: Object.keys(requestQuery ?? {}).sort(),
          httpStatus: status,
        });
        return {
          ok: false,
          error: errorDetails(
            "UPSTREAM_REQUEST_MISMATCH",
            "A chamada de bens do Radar divergiu da requisição HTTP 200 observada no portal (HTTP 404). O resultado não foi interpretado como lista vazia.",
            url,
            action,
            status,
          ),
        };
      }
      return {
        ok: false,
        error: errorDetails(
          "HTTP_ERROR",
          `A API da Âncora retornou HTTP ${status} em ${url}.`,
          url,
          action,
          status,
        ),
      };
    }

    if (label === "assets") {
      console.log(`[ANCORA BRIDGE] assets received: ${countItems(data)}`);
      console.log("[ANCORA BRIDGE] resposta recebida");
    }
    console.log(`[ANCORA BRIDGE] ${label} response received`);
    return { ok: true, payload: data ?? null, httpStatus: status };
  }


  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.channel !== CHANNEL || msg.direction !== "ancora-page-request") return;

    const operation = msg.type === "GET_ANCORA_PRODUCTS" ? getAncoraProducts() : callApi(msg.payload);
    operation
      .then((r) =>
        r.ok
          ? reply(msg.id, true, r.payload, undefined, r.httpStatus)
          : reply(msg.id, false, undefined, r.error, r.error?.httpStatus),
      )
      .catch((err) => {
        console.error("[ANCORA PAGE BRIDGE] erro", err);
        reply(msg.id, false, undefined, {
          code: "UPSTREAM_ERROR",
          message: String(err?.message ?? err),
        });
      });
  });
})();

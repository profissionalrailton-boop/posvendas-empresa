// Page script (MAIN world) — roda dentro da página do Convert+ já autenticada.
// Executa o fetch no contexto real da página; o navegador cuida da sessão.
// Nunca lê document.cookie, PHPSESSID ou tokens.

(() => {
  const CHANNEL = "infinity-convertmais-bridge";
  const PRODUTOS_URL =
    "https://www.convertmais.com.br/AdminConvertMais/ConvertMaisWeb/common/getProdutos.php";
  const PLANOS_URL =
    "https://www.convertmais.com.br/AdminConvertMais/ConvertMaisWeb/simulacao/acoes/getPlanos.php";
  const GRUPOS_URL =
    "https://www.convertmais.com.br/AdminConvertMais/ConvertMaisWeb/grupos/acoes/getGrupos.php";
  const GRUPO_DETALHES_URL =
    "https://www.convertmais.com.br/AdminConvertMais/ConvertMaisWeb/grupos/acoes/getGrupoDetalhes.php";

  if (window.__infinityConvertPageBridgeLoaded) return;
  window.__infinityConvertPageBridgeLoaded = true;

  console.log("[CONVERT PAGE BRIDGE] carregado");

  function reply(id, action, ok, payload, error) {
    window.postMessage(
      { channel: CHANNEL, direction: "page-response", id, action, ok, payload, error },
      window.location.origin,
    );
  }

  function noSession(message) {
    return { ok: false, error: { code: "NO_SESSION", message } };
  }

  /**
   * Detecta erro de APLICAÇÃO: HTTP 200 mas corpo com http_response != 200
   * e/ou msg_erro. Retorna um objeto de erro estruturado ou null.
   */
  function applicationError(json, label) {
    if (!json || typeof json !== "object") return null;
    const httpResponse =
      json.http_response !== undefined && json.http_response !== null
        ? Number(json.http_response)
        : null;
    const msg = json.msg_erro ?? json.mensagem_erro ?? json.erro ?? null;
    const hasHttpError = httpResponse !== null && httpResponse !== 200;
    if (!hasHttpError && !msg) return null;

    if (httpResponse !== null) {
      console.log(`[CONVERT PAGE BRIDGE] ${label} application response:`, httpResponse);
    }
    if (msg) {
      console.log(`[CONVERT PAGE BRIDGE] ${label} application error:`, msg);
    }

    const code = httpResponse === 401 || httpResponse === 403 ? "NO_SESSION" : "UPSTREAM_ERROR";
    const parts = [];
    if (httpResponse !== null) parts.push(`Convert+ retornou ${httpResponse}`);
    if (msg) parts.push(String(msg));
    return {
      ok: false,
      error: {
        code,
        httpResponse,
        message: parts.join(" — ") || "Convert+ retornou um erro de aplicação.",
      },
    };
  }

  async function getProducts() {
    console.log("[CONVERT PAGE BRIDGE] location.href:", window.location.href);
    console.log("[CONVERT PAGE BRIDGE] request URL:", PRODUTOS_URL);
    console.log("[CONVERT PAGE BRIDGE] X-Requested-With: XMLHttpRequest");
    console.log("[CONVERT PAGE BRIDGE] fetch started");

    const res = await fetch(PRODUTOS_URL, {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest",
      },
    });

    console.log("[CONVERT PAGE BRIDGE] response status:", res.status);
    console.log(
      "[CONVERT PAGE BRIDGE] response content-type:",
      res.headers.get("content-type") ?? "null",
    );

    const text = await res.text();

    if (!res.ok) {
      console.log("[CONVERT PAGE BRIDGE] error body preview:", text.slice(0, 300));
      if (res.status === 401 || res.status === 403) {
        return noSession(
          "Sessão do Convert+ não encontrada. Faça login no Convert+ e tente novamente.",
        );
      }
      return {
        ok: false,
        error: { code: "UPSTREAM_ERROR", message: `Convert+ retornou HTTP ${res.status}.` },
      };
    }

    let json;
    try {
      json = JSON.parse(text);
    } catch {
      console.log("[CONVERT PAGE BRIDGE] error body preview:", text.slice(0, 300));
      return noSession("Resposta inválida do Convert+ (provável redirecionamento para login).");
    }

    const appErr = applicationError(json, "GET_PRODUCTS");
    if (appErr) return appErr;

    if (!json || !Array.isArray(json.produtos)) {
      return {
        ok: false,
        error: { code: "UPSTREAM_ERROR", message: "Resposta sem a propriedade 'produtos'." },
      };
    }

    console.log("[CONVERT PAGE BRIDGE] products received:", json.produtos.length);
    return { ok: true, payload: { produtos: json.produtos } };
  }

  async function getPlans(payload) {
    const p = payload ?? {};
    const body = new URLSearchParams({
      id_grupo: String(p.id_grupo ?? "0"),
      id_produto: String(p.id_produto ?? ""),
      valor_credito_inicial: String(p.valor_credito_inicial ?? "0"),
      valor_credito_final: String(p.valor_credito_final ?? "0"),
      valor_parcela_inicial: String(p.valor_parcela_inicial ?? "0"),
      valor_parcela_final: String(p.valor_parcela_final ?? "0"),
      prazo: String(p.prazo ?? ""),
      tipo_negociacao: String(p.tipo_negociacao ?? "R"),
      situacao_grupo: String(p.situacao_grupo ?? "F"),
      tipo_venda: String(p.tipo_venda ?? p.id_tipo_venda ?? ""),
      id_tipo_venda: String(p.id_tipo_venda ?? ""),
      id_agrupamento_plano: String(p.id_agrupamento_plano ?? ""),
      tipo_pessoa: String(p.tipo_pessoa ?? "F"),
      mais_por_menos: String(p.mais_por_menos ?? "true"),
      calc_porcentagem: String(p.calc_porcentagem ?? "false"),
      limit: String(p.limit ?? "50"),
      offset: String(p.offset ?? "1"),
    });

    console.log("[CONVERT PAGE BRIDGE] GET_PLANS request started");
    console.log("[CONVERT PAGE BRIDGE] request URL:", PLANOS_URL);
    console.log("[CONVERT PAGE BRIDGE] GET_PLANS body:", body.toString());

    const res = await fetch(PLANOS_URL, {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest",
      },
      body,
    });

    console.log("[CONVERT PAGE BRIDGE] GET_PLANS response status:", res.status);
    console.log(
      "[CONVERT PAGE BRIDGE] response content-type:",
      res.headers.get("content-type") ?? "null",
    );

    const text = await res.text();

    if (!res.ok) {
      console.log("[CONVERT PAGE BRIDGE] error body preview:", text.slice(0, 300));
      if (res.status === 401 || res.status === 403) {
        return noSession(
          "Sessão do Convert+ não encontrada. Faça login no Convert+ e tente novamente.",
        );
      }
      return {
        ok: false,
        error: { code: "UPSTREAM_ERROR", message: `Convert+ retornou HTTP ${res.status}.` },
      };
    }

    let json;
    try {
      json = JSON.parse(text);
    } catch {
      console.log("[CONVERT PAGE BRIDGE] error body preview:", text.slice(0, 300));
      return noSession("Resposta inválida do Convert+ (provável redirecionamento para login).");
    }

    const appErr = applicationError(json, "GET_PLANS");
    if (appErr) return appErr;

    const planos = Array.isArray(json?.planos)
      ? json.planos
      : Array.isArray(json)
        ? json
        : Array.isArray(json?.data)
          ? json.data
          : null;

    if (!planos) {
      console.log("[CONVERT PAGE BRIDGE] error body preview:", text.slice(0, 300));
      return {
        ok: false,
        error: { code: "UPSTREAM_ERROR", message: "Resposta sem a propriedade 'planos'." },
      };
    }

    console.log("[CONVERT PAGE BRIDGE] plans received:", planos.length);
    return { ok: true, payload: { planos } };
  }

  async function getGroups(payload) {
    const p = payload ?? {};
    const body = new URLSearchParams({
      id_produto: String(p.id_produto ?? ""),
      id_tipo_venda: String(p.id_tipo_venda ?? ""),
      id_plano_venda: String(p.id_plano_venda ?? ""),
      id_taxa_plano: String(p.id_taxa_plano ?? ""),
      prazo: String(p.prazo ?? ""),
      id_bem: String(p.id_bem ?? ""),
      situacao: String(p.situacao ?? "A"),
    });

    console.log("[CONVERT PAGE BRIDGE] GET_GROUPS request started");
    console.log("[CONVERT PAGE BRIDGE] request URL:", GRUPOS_URL);
    console.log("[CONVERT PAGE BRIDGE] GET_GROUPS body:", body.toString());

    const res = await fetch(GRUPOS_URL, {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest",
      },
      body,
    });

    console.log("[CONVERT PAGE BRIDGE] GET_GROUPS response status:", res.status);
    console.log(
      "[CONVERT PAGE BRIDGE] response content-type:",
      res.headers.get("content-type") ?? "null",
    );

    const text = await res.text();

    if (!res.ok) {
      console.log("[CONVERT PAGE BRIDGE] error body preview:", text.slice(0, 300));
      if (res.status === 401 || res.status === 403) {
        return noSession(
          "Sessão do Convert+ não encontrada. Faça login no Convert+ e tente novamente.",
        );
      }
      return {
        ok: false,
        error: { code: "UPSTREAM_ERROR", message: `Convert+ retornou HTTP ${res.status}.` },
      };
    }

    let json;
    try {
      json = JSON.parse(text);
    } catch {
      console.log("[CONVERT PAGE BRIDGE] error body preview:", text.slice(0, 300));
      return noSession("Resposta inválida do Convert+ (provável redirecionamento para login).");
    }

    const appErr = applicationError(json, "GET_GROUPS");
    if (appErr) return appErr;

    const grupos = Array.isArray(json?.grupos)
      ? json.grupos
      : Array.isArray(json)
        ? json
        : Array.isArray(json?.data)
          ? json.data
          : null;

    if (!grupos) {
      console.log("[CONVERT PAGE BRIDGE] error body preview:", text.slice(0, 300));
      return {
        ok: false,
        error: { code: "UPSTREAM_ERROR", message: "Resposta sem a propriedade 'grupos'." },
      };
    }

    const semVagas = Array.isArray(json?.grupos_sem_vagas) ? json.grupos_sem_vagas : [];
    console.log("[CONVERT PAGE BRIDGE] groups received:", grupos.length);
    console.log("[CONVERT PAGE BRIDGE] groups without slots:", semVagas.length);
    return { ok: true, payload: { grupos, grupos_sem_vagas: semVagas } };
  }

  async function getGroupDetails(payload) {
    const p = payload ?? {};
    const body = new URLSearchParams({
      id_produto: String(p.id_produto ?? ""),
      id_tipo_venda: String(p.id_tipo_venda ?? ""),
      id_plano_venda: String(p.id_plano_venda ?? ""),
      id_taxa_plano: String(p.id_taxa_plano ?? ""),
      prazo: String(p.prazo ?? ""),
      id_bem: String(p.id_bem ?? ""),
      id_grupo: String(p.id_grupo ?? ""),
    });

    console.log("[GROUP DETAILS] request enviada");
    console.log("[CONVERT PAGE BRIDGE] request URL:", GRUPO_DETALHES_URL);
    console.log("[CONVERT PAGE BRIDGE] GET_GROUP_DETAILS body:", body.toString());

    const res = await fetch(GRUPO_DETALHES_URL, {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest",
      },
      body,
    });

    console.log("[GROUP DETAILS] response status:", res.status);
    const text = await res.text();

    if (!res.ok) {
      console.log("[CONVERT PAGE BRIDGE] error body preview:", text.slice(0, 300));
      if (res.status === 401 || res.status === 403) {
        return noSession(
          "Sessão do Convert+ não encontrada. Faça login no Convert+ e tente novamente.",
        );
      }
      return {
        ok: false,
        error: { code: "UPSTREAM_ERROR", message: `Convert+ retornou HTTP ${res.status}.` },
      };
    }

    let json;
    try {
      json = JSON.parse(text);
    } catch {
      console.log("[CONVERT PAGE BRIDGE] error body preview:", text.slice(0, 300));
      return noSession("Resposta inválida do Convert+ (provável redirecionamento para login).");
    }

    const appErr = applicationError(json, "GET_GROUP_DETAILS");
    if (appErr) return appErr;

    console.log("[GROUP DETAILS] resposta recebida");
    console.log("[CONVERT PAGE BRIDGE] group details keys:", Object.keys(json ?? {}));
    // Payload CRU: o mapeamento dos campos reais é feito no Infinity.
    return { ok: true, payload: json };
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.channel !== CHANNEL || msg.direction !== "page-request") return;
    const raw = msg.action ?? msg.type;
    const isProducts = raw === "getProducts" || raw === "GET_PRODUCTS";
    const isPlans = raw === "getPlans" || raw === "GET_PLANS";
    const isGroups = raw === "getGroups" || raw === "GET_GROUPS";
    const isGroupDetails = raw === "getGroupDetails" || raw === "GET_GROUP_DETAILS";
    if (!isProducts && !isPlans && !isGroups && !isGroupDetails) return;

    const action = isProducts
      ? "getProducts"
      : isPlans
        ? "getPlans"
        : isGroups
          ? "getGroups"
          : "getGroupDetails";
    console.log("[CONVERT PAGE BRIDGE] request received", action);

    const run = isProducts
      ? getProducts()
      : isPlans
        ? getPlans(msg.payload)
        : isGroups
          ? getGroups(msg.payload)
          : getGroupDetails(msg.payload);
    run
      .then((r) =>
        r.ok
          ? reply(msg.id, action, true, r.payload)
          : reply(msg.id, action, false, undefined, r.error),
      )
      .catch((err) => {
        console.error("[CONVERT PAGE BRIDGE] erro", err);
        reply(msg.id, action, false, undefined, {
          code: "UPSTREAM_ERROR",
          message: String(err?.message ?? err),
        });
      });
  });
})();
